module.exports = {
    "databaseURL" : "https://hirebus-app-default-rtdb.firebaseio.com/"
};
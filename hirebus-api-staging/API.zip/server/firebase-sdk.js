// For Firebase JS SDK v7.20.0 and later, measurementId is optional

const firebaseConfig = {
  apiKey: "AIzaSyAI4pdIKMip6tOBjm8R3ca_gvh_KiSepdg",
  authDomain: "hirebus-app.firebaseapp.com",
  projectId: "hirebus-app",
  storageBucket: "hirebus-app.appspot.com",
  messagingSenderId: "225800033786",
  appId: "1:225800033786:web:16f8676ac143c96c0cc043",
  measurementId: "G-SCDPZMTX0Z"
};
module.exports = firebaseConfig;
const moment = require('moment')

const getDriverAllowance = (startDate, startTime, returnDate, returnTime) => {
    let start = moment(`${startDate} ${startTime}`, 'DD-MM-YYYY HH:mm');
    let end = moment(`${returnDate} ${returnTime}`, 'DD-MM-YYYY HH:mm');
    console.log('Hours...', moment.duration(end.diff(start)).asHours());
    return 700 * Math.ceil(moment.duration(end.diff(start)).asHours() / 24);
}

module.exports = {
    getDriverAllowance
};
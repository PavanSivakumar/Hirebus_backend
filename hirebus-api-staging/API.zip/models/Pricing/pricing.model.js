const mongoose = require('mongoose');
const _ = require('lodash')
const Schema = mongoose.Schema;

let pricingSchema = new Schema({
    maxHours: {
        type: Number,
    },
    maxKms: {
        type: Number,
    },
    cost: {
        type: Number,
    }
});

async function getAllPricing(req) {
    console.log('req...',req);
    let { totalKms, totalHours, costPerKms, extraCostPerKm, extraCostPerHour } = req || {};
    try {
        if(totalKms > 250) {
            return ({ status: 1, pricing: costPerKms * totalKms });
        }
        let maxKms = await Pricing.findOne({ maxKms: { $gte: totalKms } })
        let maxHours = await Pricing.findOne({ maxHours: { $gte: totalHours } })
        let pricing = _.maxBy([maxKms, maxHours], 'cost');
        console.log('maxKms...', maxKms);
        console.log('maxHours...', maxHours);
        console.log('pricing...', pricing);
        if (!pricing) {
            throw new Error("No Pricing Data found!");
        }
        let extraKms = totalKms - pricing.maxKms;
        console.log('extraKms...',extraKms);
        let extraHours = totalHours - pricing.maxHours;
        console.log('extraHours...',extraHours);
        let price = pricing.cost + ((extraKms > 0 ? extraKms : 0) * extraCostPerKm) + ((extraHours > 0 ? extraHours : 0) * extraCostPerHour);
        console.log('price...',price);
        return ({ status: 1, pricing: price });
    }
    catch (err) {
        console.log('catchng...');
        return ({ status: 0, pricing: NULL, message: err.message });
    }
}

const Pricing = mongoose.model('Pricing', pricingSchema);
module.exports = {
    Pricing,
    getAllPricing
}
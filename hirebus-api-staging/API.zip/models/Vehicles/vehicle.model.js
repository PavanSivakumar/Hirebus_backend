const _ = require('lodash')
const mongoose = require("mongoose");
const Schema = mongoose.Schema;
const { Trip, getTripByCondition } = require("../Trips/trip.model");
const moment = require('moment')

let vehicleSchema = new Schema({
  vehicleId: {
    type: String,
  },
  vehicleName: {
    type: String,
    maxlength: 200,
    required: true,
  },
  travelAgencyName: {
    type: String,
    required: true,
  },
  busPlateNumber: {
    type: String,
    required: true,
  },
  busType: {
    type: String,
    required: true,
  },
  owner: {
    type: Schema.Types.ObjectId,
    ref: "Vendor",
  },
  facilities: [
    {
      type: String,
    },
  ],
  cancellationPolicy: [
    {
      durationInDays: {
        type: Number,
      },
      percentRefund: {
        type: Number,
      },
    },
  ],
  instructions: [
    {
      type: String,
    },
  ],
  imagesArray: [
    {
      type: String,
      maxlength: 3000,
    },
  ],
  packages: [{
    type: Schema.Types.ObjectId,
    ref: "Package",
  }],
  minDistance: {
    type: Number,
  },
  minCost: {
    type: Number,
  },
  seatCapacity: {
    type: Number,
  },
  leftSeatSize: {
    type: Number,
  },
  rightSeatSize: {
    type: Number,
  },
  totalSeats: {
    type: Number,
  },
  isEnabled: {
    type: Boolean,
    default: true,
  },

  // chennai (chennai)
  placeOfOrigin: {
    type: String,
  },


  isAC: {
    type: Boolean,
    default: false,
  },

  // 
  costPerKm: {
    type: Number,
    required: true,
  },
  // securityDepositToCollect
  securityDeposit: {
    type: Number,
    required: true,
  },
  driverCost: {
    type: Number,
    required: true,
  },
});

async function getVehicles(Location, passengers, pageNumber, isAC, busType,
  startDate, startTime, returnDate, returnTime
) {

  let body = {
    placeOfOrigin: Location,
    isEnabled: true,
    seatCapacity: { $gte: passengers },
  };

  if (isAC === false) {
    body = {
      ...body,
      $or: [
        { isAC: { $exists: false } },
        { isAC: isAC },
      ],
    }
  } else if (isAC === true) {
    body = {
      ...body,
      isAC: isAC,
    }
  }

  if (busType !== undefined) {
    body = {
      ...body,
      busType: busType,
    }
  }
  //console.log('body...', body);
  let result = await Vehicle.find({ ...body })
    .populate("owner packages")
    .sort({ $natural: -1 })
    .limit(15);

  let filteredVehicles = [];
  console.log('result....', result.length)
  if (!_.isEmpty(result)) {

    await Promise.all(await result.map(async (item) => {
      console.log('item....', item._id)
      let trips = await Trip.find({ status: 1, busDetails: item._id });
      let hasTrip = false;
      //console.log('trips....', trips)
      if (!_.isEmpty(trips)) {
        await trips.map(async (trip) => {
          
          console.log('tripsfd....', trip)
          console.log(`${trip.departureDate} ${trip.departureTime}`)
          console.log(`${trip.returnDate} ${trip.returnTime}`)
          console.log(`${startDate} ${startTime}`)
          console.log(`${returnDate} ${returnTime}`)
          let start = moment(`${trip.departureDate} ${trip.departureTime}`, 'DD-MM-YYYY HH:mm');
          let end = moment(`${trip.returnDate} ${trip.returnTime}`, 'DD-MM-YYYY HH:mm').add({ hours: 11, minutes: 59 });
          //New
          let s = moment(`${startDate} ${startTime}`, 'DD-MM-YYYY HH:mm');
          let e = moment(`${returnDate} ${returnTime}`, 'DD-MM-YYYY HH:mm');

          console.log('t start...', start)
          console.log('t end...', end)
          console.log('s...', s)
          console.log('e...', e)
          if (
            (s.isSameOrAfter(start) && s.isSameOrBefore(end)) ||
            (e.isSameOrAfter(start) && e.isSameOrBefore(end))
          ) {
            if (!hasTrip) {
              hasTrip = true;
            }
          }
        })
      } else {
        console.log('empty...');
      }
      if (!hasTrip) {
        filteredVehicles.push(item);
      }
      // if(result.indexOf(item) == result.length - 1) {
      //   console.log('filteredVehicles', filteredVehicles);
      //   return filteredVehicles;
      // }
    }));
    console.log('filteredVehicles', filteredVehicles);
    return filteredVehicles;

  }
  return [];
  // _.filter(result, (item) => {
  //   item.
  // })

//console.log('filteredVehicles', filteredVehicles);

  ////return result;
}

async function getVehicle(vehicleId, cb) {
  try {
    console.log(vehicleId, "---------vehicleId");
    Vehicle.findOne({ _id: vehicleId })
      .populate("owner packages")
      .exec((err, resp) => {
        console.log("Error" + JSON.stringify(err));
        console.log("Response: " + JSON.stringify(resp));
        if (err || !resp) throw new Error("No Vechiles Found");
        return cb({ status: 1, vehicle: resp });
      });
  } catch (err) {
    return cb({ status: 0, vehicle: NULL, message: err });
  }
}

const Vehicle = mongoose.model("Vehicle", vehicleSchema);
module.exports = {
  Vehicle,
  getVehicles,
  getVehicle,
};

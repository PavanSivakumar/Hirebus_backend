const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let packageSchema = new Schema({
    packageName : {
        type:String,
    },
    packageFacilities : [{
        type :String,
    }],
    costPerKm : {
        type : Number,
    },
    extraCostPerKm : {
        type : Number,
    },
    extraCostPerHour : {
        type : Number,
    },
    minimumDuration : {
        type : Number,
        default : 24, //in hours
    },
    driverAllowance: {
        type : Number,
        default : 0,
    },
    securityDepositToCollect : {
        type :Number,  //in percentage
        default : 0,
    },
    isAc: {
        type : Boolean,  //in percentage
        default : false,
        required: true
    }
});

const Package = mongoose.model('Package', packageSchema);

module.exports = { 
    Package
}
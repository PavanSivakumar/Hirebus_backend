const mongoose = require("mongoose");
const { Vendor } = require("../Vendors/vendor.model");
const Schema = mongoose.Schema;
var Float = require("mongoose-float").loadType(mongoose);

let tripSchema = new Schema({
  customerId: {
    type: Schema.Types.ObjectId,
    ref: "Customer",
  },
  phoneNumber: {
    type: String,
  },
  tripId: {
    type: String,
  },
  title: {
    type: String,
    required: true,
    maxlength: 300,
  },
  enquiryTime: {
    type: Number, //Date.parse( stringDate) <-> new Date(parsedDate)
  },
  status: {
    type: Number, //ENQUIRY0 SCHEDULED1  IN-PROGRESS2 COMPLETED3 CANCELLED4........
  },
  departureDate: {
    type: String,
    required: true,
  },
  departureTime: {
    type: String,
    required: true,
  },
  returnDate: {
    type: String,
    required: true,
  },
  returnTime: {
    type: String,
    required: true,
  },
  busDetails: {
    type: Schema.Types.ObjectId,
    ref: "Vehicle",
  },
  packageChosen: {
    type: Schema.Types.ObjectId,
    ref: "Package",
  },
  couponApplied: {
    type: Schema.Types.ObjectId,
    ref: "Coupon",
  },
  publicCouponApplied: {
    type: Schema.Types.ObjectId,
    ref: "PublicCoupon",
  },
  passengerNumber: {
    type: Number,
    required: true,
  },
  roundTrip: {
    type: Boolean,
    required: true,
  },
  companyInfo: {
    companyId: {
      type: Schema.Types.ObjectId,
      ref: "Company",
    },
    chosenDate: {
      type: String,
    },
    people: {
      type: Number,
    },
  },
  startLocation: {
    name: {
      type: String,
    },
    cityName: {
      type: String,
    },
    lat: {
      type: String,
    },
    lng: {
      type: String,
    },
  },
  stopsLocation: [
    {
      name: {
        type: String,
      },
      lat: {
        type: String,
      },
      lng: {
        type: String,
      },
      date: {
        type: String,
      },
      time: {
        type: String,
      },
    },
  ],
  endLocation: {
    name: {
      type: String,
    },
    lat: {
      type: String,
    },
    lng: {
      type: String,
    },
  },
  estimatedDistInKm: {
    type: Number,
    default: 0,
  },
  tripCost: {
    type: Number,
    default: 0,
  },
  city: {
    type: Number,
  },
  refund: {
    type: Number,
    defualt: 0,
  },
  additionalCosts: [
    {
      description: {
        type: String,
      },
      amount: {
        type: Number,
      },
    },
  ],
  remainingAmount: {
    type: Number,
    default: 0,
  },
  tripStartTime: {
    type: Number,
  },
  tripEndTime: {
    type: Number,
  },
  odoMeterStartNumber: {
    type: Number,
  },
  odoMeterStartScreenshotURL: {
    type: String,
  },
  odoMeterEndNumber: {
    type: Number,
  },
  odoMeterEndScreenshotURL: {
    type: String,
  },
  paymentIds: [
    {
      type: Schema.Types.ObjectId,
      ref: "Payment",
    },
  ],
  CBC: {
    type: Number,
    default: 0,
  },
  driverAllowance: {
    type: Number,
  },
  GST: {
    type: Number,
  },
  partialAmountToPay: {
    type: Number,
  },
  baseFare: {
    type: Number,
  },
  securityDeposit: {
    type: Number,
  },
  bookingDuration: {
    type: Number,
  },
  extraDistance: {
    type: Number,
  },
  extraDuration: {
    type: Number,
  },
  endExtraCost: {
    type: Number,
  },
});

async function createTrip(tripObj, cb) {
  try {
    let trip = await new Trip(tripObj).save();
    //console.log('before populate...', trip);
    trip = await trip.populate({
      path: "customerId",
      select: "email firstName lastName email phoneNumber busDetails owner packageChosen packages",
    })
    .populate({ path: "busDetails", populate: { path: "owner" } })
    .populate({ path: "busDetails", model: 'Package' })
    .populate("packageChosen")
    .populate("companyInfo.companyId").execPopulate();
   // console.log('after populate...', trip);
    if (!trip) throw new Error("Trip has not been registered yet!");
    cb({ status: 1, trip: trip });
  } catch (err) {
    cb({ status: 0, message: err });
  }
}

async function updateTrip(
  tripId,
  totalCost,
  phoneNumber,
  amountPaid,
  tripStatus,
  field,
  coupon,
  paymentId,
  cb
) {
  let object;

  if (field === null) {
  }
  if (field === "couponApplied") {
    object = {
      status: tripStatus,
      phoneNumber: phoneNumber,
      couponApplied: coupon,
    };
  } else {
    object = {
      status: tripStatus,
      phoneNumber: phoneNumber,
      publicCouponApplied: coupon,
    };
  }

  if (field === null) {
    console.log("Field is null");
    object = {
      status: tripStatus,
      phoneNumber: phoneNumber,
      couponApplied: null,
    };
  }

  try {
    Trip.findOneAndUpdate(
      { _id: tripId },
      {
        $set: {...object, remainingAmount: totalCost - amountPaid, tripCost: totalCost},
        $push: {
          paymentIds: paymentId,
         // additionalCosts: { description: "Coupon Cost", amount: totalCost },
        },
       // $inc: { remainingAmount: totalCost - amountPaid, tripCost: totalCost },
      }
    ).exec((err, resp) => {
      console.log("resp...", resp);
      if (err) {
        console.log(err);
        throw new Error(err);
      }
      if (!resp) throw new Error("Something went wrong!");
      return cb({ status: 1, trip: resp });
    });
  } catch (err) {
    return cb({ status: 0, message: err });
  }
}

async function updateTripStatus(
  tripId,
  status,
  cb
) {
 
  try {
    Trip.findOneAndUpdate(
      { _id: tripId },
      {
        $set: {status: status},
      }
    ).exec((err, resp) => {
      if (err) {
        console.log(err);
        throw new Error(err);
      }
      if (!resp) throw new Error("Something went wrong!");
      return cb({ status: 1, trip: resp });
    });
  } catch (err) {
    return cb({ status: 0, message: err });
  }
}

async function getTrip(tripId) {
  try {
    let trip = await Trip.findOne({ _id: tripId })
      .populate({
        path: "customerId",
        select: "email firstName lastName email phoneNumber busDetails owner packageChosen packages paymentIds",
      })
      .populate({ path: "busDetails", populate: { path: "owner" } })
      .populate({ path: "busDetails", model: 'Package' })
      .populate("packageChosen")
      .populate("companyInfo.companyId")
      .populate("paymentIds")
      .exec();
    console.log('trip...', trip);
    if (!trip) throw new Error("No trip found!");
    return { status: 1, trip: trip };
  } catch (err) {
    return { status: 0, message: err };
  }
}
async function getTripByCondition(props) {
  try {
    let trip = await Trip.find({ ...props})
      .populate({
        path: "customerId",
        select: "email firstName lastName email phoneNumber busDetails owner packageChosen packages paymentIds",
      })
      .populate({ path: "busDetails", populate: { path: "owner" } })
      .populate({ path: "busDetails", model: 'Package' })
      .populate("packageChosen")
      .populate("companyInfo.companyId")
      .populate("paymentIds")
      .exec();
    console.log('trip...', trip);
    if (!trip) return { status: 0, message: "Not found!" };
    return { status: 1, trip: trip };
  } catch (err) {
    return { status: 0, message: err };
  }
}

async function getTrips(pageNumber, status) {
  try {
    let trips = await Trip.find({ status: status })
      .populate({ path: "customerId", select: "firstName lastName" })
      .sort({ $natural: -1 })
      .skip(15 * pageNumber)
      .limit(15)
      .exec();
    if (!trips) {
      throw new Error("No trips found!");
    }
    // console.log(trips);
    return { status: 1, trips: trips };
  } catch (err) {
    return { status: 0, trips: NULL, message: err };
  }
}

async function getTripsinDays(days) {
  let time = 1000 * 60 * 60 * 24 * (days + 1) + 1;
  let timeNow = Date.parse(new Date());
  time = timeNow - time;
  // console.log(time);
  let revenue;
  try {
    let enquiry = await Trip.countDocuments({
      enquiryTime: { $gte: time },
      status: 0,
    });
    // console.log(enquiry);
    if (!enquiry) throw new Error("Couldn't count enquiry!");
    let scheduled = await Trip.countDocuments({
      enquiryTime: { $gte: time },
      status: 1,
    })
      .then()
      .catch((err) => {
        throw new Error(err);
      });
    let progress = await Trip.countDocuments({
      enquiryTime: { $gte: time },
      staus: 2,
    })
      .then()
      .catch((err) => {
        throw new Error(err);
      });
    let completed = await Trip.countDocuments({
      enquiryTime: { $gte: time },
      staus: 3,
    })
      .then()
      .catch((err) => {
        throw new Error(err);
      });
    await Trip.aggregate([
      { $match: { enquiryTime: { $gte: time } } },
      {
        $group: {
          _id: null,
          total: { $sum: "$tripCost" },
        },
      },
    ])
      .exec()
      .then((res) => {
        // console.log(res);
        revenue = res;
      })
      .catch((err) => {
        // console.log(err);
        if (err) throw new Error("Can't find revenue");
      });
    return {
      status: 1,
      enquiry: enquiry,
      scheduled: scheduled,
      progress: progress,
      completed: completed,
      revenue: revenue[0].total,
    };
  } catch (err) {
    // console.log(err);
    return { status: 0, message: err };
  }
}

const Trip = mongoose.model("Trip", tripSchema);
module.exports = {
  Trip,
  createTrip,
  updateTrip,
  updateTripStatus,
  getTrip,
  getTrips,
  getTripsinDays,
  getTripByCondition,
};

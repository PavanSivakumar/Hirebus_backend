const express = require('express');
let router = express.Router();
let { sendOTP ,  verifyOTP } = require('../helpers/sendotp');
let { addVendorEarning } = require('../../models/vendorEarnings/vendorEarning');
let { Trip } = require('../../models/Trips/trip.model');
let { Vendor } = require('../../models/Vendors/vendor.model');
const cors = require('../cors');


router.post('/startTrip' , cors.cors, async(req, res)=>{
    let tripId = req.query.tripId;
    // console.log(tripId);
    try {   
        Trip.findOne({_id : tripId } ).exec((err , resp)=>{
            // console.log(err, resp);
            if(err || !resp) res.status(500).send({status : 0 , message : "No Trip Exists!"});
            // send
                //check the phooneNumber vairbale
            // sendOTP(trip.phoneNumber , data=>{
                // if(data.status===0) throw new Error(data.message);
                return res.status(200).send({ status : 1 , phoneNumber : trip.phoneNumber, message : "OTP  has been sent!"});
            // })
        })
    }catch(err){
        return res.status(500).send({status : 0 , message : err});
    }
})

router.post('/verifyStartTrip' , cors.cors, async(req, res)=>{
    let { otp , tripId , odoMeterStartNumber, odoMeterStartScreenshotURL } = req.body || {} ;
    try{
        Trip.findOne({_id : tripId } ).exec((er , trip)=>{
            if(er || !trip) res.status(500).send({status : 0 , message : (er || "Trip not found!!")});
            // verifyOTP(trip.phoneNumber, otp, (data)=>{
                // if(data.status===0) throw new Error(data.message);
                Trip.findOneAndUpdate({_id : tripId} , { $set : {
                    odoMeterStartNumber : odoMeterStartNumber, 
                    odoMeterStartScreenshotURL : odoMeterStartScreenshotURL,
                    tripStartTime : Date.now(),
                    status : 3, // set to In PRogress status code
                }}).exec((err , resp) =>{
                    if(err || !resp) throw new Error("Couldn't update trip!");
                    return res.status(200).send({status : 1, message : "Trip has been started!" });
                })
            // })
        });
    }catch(err){
        return res.status(500).send({status : 0 , message : err});
    }
})

router.post('/collectedPayment' , cors.cors, async(req,res) =>{
    let { tripId, paymentCollected } = req.body || {};
    try { 
        if( !paymentCollected ) throw new Error( "Payment has not been collected" );
        Trip.findOneAndUpdate({_id : tripId} , { remainingAmount : 0}).populate('busDetails').exec((err , resp)=>{
            if(err) throw new Error("Trip is not found!!");
            let vendorEarningObj = {
                vendor : resp.busDetails.owner,
                trip : tripId,
                amount : resp.remainingAmount,
                transactionDate  : new Date(),
                customer : resp.customerId
            };
            addVendorEarning(vendorEarningObj , (earning)=>{
                if(earning.status===0) throw new Error(earning.message);
            });
            Vendor.findOneAndUpdate({ _id : resp.busDetails.owner} , { $inc : { amountEarned : resp.remainingAmount }})
            .exec((err,resp)=>{
                if(err) throw new Error(err);
                if(!resp) throw new Error("Earnings of vendor could not be added!");
            });
            return res.status(200).send({status : 1 ,  message : "Amount has been collected!"});
        }) 
    }catch(err){
        return res.status(500).send({status : 0 , message : "Something went wrong. Try again!"});
    }
})

router.post('/endTrip' , cors.cors, async(req, res)=>{
    let tripId = req.query.tripId;
    try {   
        Trip.findOne({_id : tripId } ).exec((err , resp)=>{
        if(err || !resp) return res.status(500).send({status : 0 , message : err || "Couldn't send OTP!"});
            // sendOTP(trip.phoneNumber , data=>{
            //     if(data.status===0) throw new Error(data.message);
                Trip.findOneAndUpdate({_id : tripId} , { $set : {tripEndTime : Date.now()} }).exec((err2 , resp2) =>{
                    if(err2 || !resp2) throw new Error("Couldn't update trip!");
                    return res.status(200).send({ status : 1 , phoneNumber : resp.phoneNumber, message : "OTP  has been sent!"});
                })
            // })
        })
    }catch(err){
        return res.status(500).send({status : 0 , message : err});
    }
})

router.post('/verifyEndTrip', cors.cors, async(req, res)=>{
    let { otp , tripId , odoMeterEndNumber, odoMeterEndScreenshotURL , damages } = req.body || {} ;

    let cost = 0;
    if(damages){
        for(let i = 0 ; i< damages.length ;i++){
            cost += damages[i].amount;
        }
    }
    let extraTime = 0 , extraDistance = 0;
    try{
        Trip.findOne({_id : tripId } ).exec((er ,trip)=>{
            // verifyOTP(trip.phoneNumber, otp, (data)=>{
            //     if(data.status===0) throw new Error(data.message);
                Trip.findOneAndUpdate({_id : tripId} , {
                    odoMeterEndNumber : odoMeterEndNumber, 
                    odoMeterEndScreenshotURL : odoMeterEndScreenshotURL,
                    tripEndTime : Date.now(),
                    $push : {
                        additionalCosts : damages,
                    }, $inc : {
                        remainingAmount : cost ,
                        tripCost : cost ,
                    }
                }).then((resp) =>{
                    if(!resp) throw new Error("Couldn't update trip!");
                    try { 
                        Trip.findOne({ _id : tripId }).populate('packageChosen').exec((err , trip)=>{
                            if(err || !trip) throw new Error("Trip not found!");
                            extraTime = ((trip.tripEndTime - trip.tripStartTime)/3600000 - (trip.bookingDuration)); 
                            extraDistance = trip.odoMeterEndNumber - trip.odoMeterStartNumber - trip.estimatedDistInKm;
                            let extraCost = extraTime*trip.packageChosen.extraCostPerHour + extraDistance* trip.packageChosen.extraCostPerKm;
                            Trip.findOneAndUpdate({_id : tripId} , {$inc : { remainingAmount : extraCost , tripCost : extraCost } , 
                                $push : {additionalCosts : {'description' : 'Extra cost' , amount:extraCost}} ,
                                $set : { extraDistance : extraDistance , extraDuration : extraTime , endExtraCost : cost + extraCost}
                            }).exec((err2 , resp)=>{

                                if(err2 || !resp) {
                                    console.log("ERror" + JSON.stringify(err))
                                    console.log("Resposne " + JSON.stringify(resp))
                                }
                                let fareBreakup = trip.additionalCosts;
                                fareBreakup.push( {'description' : 'Extra cost' , amount:extraCost});
                                if(trip.remainingAmount + extraCost < 0) {
                                    Trip.findOneAndUpdate({_id: tripId} , { remainingAmount : 0 , refund : -(trip.remainingAmount + extraCost) } , (err3, data)=>{
                                        if(err3 ||!data) throw new Error("Something went wrong!");
                                        return res.status(200).send({status : 2 , fareBreakup : fareBreakup , refund : -(trip.remainingAmount + extraCost) , remainingAmount : 0  });
                                    }); 
                                }
                                else {
                                    return res.status(200).send({status : 1 ,fareBreakup : fareBreakup ,refund : 0 , remainingAmount : (trip.remainingAmount + extraCost)});
                                }
                            })
                            
                        })
                    }catch(err){
                        return res.status(500).send({status : 0 , message : err});
                    }
                }).catch((err)=>{
                    throw new Error(err);
                })
            // })
        });
    }catch(err){
        return res.status(500).send({status : 0 , message : err});
    }
})

router.post('/getFare' , cors.cors, async(req, res)=>{
    let { tripId } = req.body || {};
    try{
        Trip.findOne({_id : tripId}).exec((err , trip)=>{
            if(err || !trip) return res.status(500).send({status : 0 , message : "Trip not found!"});
            res.status(200).send({status : 1 , trip: trip, fareBreakup : trip.additionalCosts , refund : trip.refund , remainingAmount : trip.remainingAmount});
        })
    }catch(err){
        return res.status(500).send({status : 0 , message : err});
    }
})


// TODO: 
router.post("/fullpaymentCollected", (req,res) => {
    // udpate tripStatus : to completed 
    // send thank you mail to customer
});
router.post('/refund' , cors.cors, async(req,res)=>{
    let { tripId } = req.body || {};
    try{
        Trip.findOneAndUpdate({_id : tripId} , { refund  : 0 }).populate('busDetails').exec((err , resp)=>{
            if(err || !resp ) throw new Error("Amount is not refunded!");
            console.log(resp);
            let vendorEarningObj = {
                vendor : resp.busDetails.owner,
                trip : tripId,
                amount : - resp.refund,
                transactionDate  : new Date(),
                customer : resp.customerId
            };
            addVendorEarning(vendorEarningObj , (earning)=>{
                if(earning.status===0) throw new Error(earning.message);
            });
            Vendor.findOneAndUpdate({ _id : resp.busDetails.owner} , { $inc : { amountEarned : - resp.refund}})
            .exec((err,resp)=>{
                if(err) throw new Error(err);
                if(!resp) throw new Error("Earnings of vendor could not be added!");
            });
            return res.status(200).send({status : 1 , message : "Amount has been refunded!"});
        })
    }catch(err){
        return res.status(500).send({status : 0 , message :err});
    }
})

module.exports = router;
